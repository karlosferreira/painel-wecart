<?php 
    remove_action( 'in_admin_header', 'wp_admin_bar_render', 0 );
    //disables top margin
    add_filter( 'admin_title', function(){ $GLOBALS['wp_query']->is_embed=true;  add_action('admin_xml_ns', function(){ $GLOBALS['wp_query']->is_embed=false; } ); } );