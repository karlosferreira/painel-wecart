<?php
/*
Plugin Name: WeCart
Description:  Disable the frontend interface of the website, leave only CMS and REST API.
Configure network and multistore woocommerce
Author: Carlos Ferreira (kyrvim@gmail.com)
Version: 1.0
*/

add_action('init', 'redirect_to_backend');

function redirect_to_backend() {
    if(
        !is_admin() &&
        !is_wplogin() &&
        !is_rest()
    ) {
    wp_redirect(site_url('wp-admin'));
    exit();
  }
}

// Formating

add_action( 'plugins_loaded', 'check_current_user' );
function check_current_user() {
    // Your CODE with user data
    $current_user = wp_get_current_user();

    // Your CODE with user capability check
    if ( $current_user->roles[0] == 'shop_manager' ) { 

		function remove_default_menu(){
			remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=category' );
			remove_menu_page('index.php'); // Dashboard
			remove_menu_page('edit.php'); // Posts
			remove_menu_page('upload.php'); // Media
			remove_menu_page('link-manager.php'); // Links
			remove_menu_page('edit.php?post_type=page'); // Pages
			remove_menu_page('edit-comments.php'); // Comments
			remove_menu_page('themes.php'); // Appearance
			remove_menu_page('plugins.php'); // Plugins
			remove_menu_page('users.php'); // Users
			remove_menu_page('tools.php'); // Tools
			remove_menu_page('options-general.php'); // Settings
			remove_menu_page( 'edit.php?post_type=acf-field-group' ); // ACF
			remove_menu_page( 'admin.php?page=wc-admin' ); // Woocommerce
			remove_menu_page( 'edit.php?post_type=product' ); // Produtos
			remove_menu_page( 'woocommerce' ); // WOOCOMMERCE
			remove_menu_page( 'admin.php?page=wc-admin' ); // WOOCOMMERCE
		}
		add_action( 'admin_menu', 'remove_default_menu' );

	}

    if ( $current_user->roles[0] == 'administrator' ) { 

		function remove_default_menu(){
			remove_menu_page('index.php'); // Dashboard
			remove_menu_page('edit.php?post_type=wecart-orders'); // Pedidos
			remove_menu_page('edit.php?post_type=wecart-assessments'); // Avaliações
			remove_menu_page('edit.php?post_type=wecart-stock'); // Estoque
			remove_menu_page('edit.php?post_type=payment-methods'); // Meios de pagamento
			remove_menu_page('edit.php?post_type=delivery_area'); // Área de entrega
			remove_menu_page('edit.php?post_type=financial'); // Financeiro
			remove_menu_page('edit.php?post_type=wecart-promo'); // Promoções
			remove_menu_page('edit.php?post_type=opening_hours'); // Horários
			remove_menu_page('edit.php?post_type=wecart-profile'); // Perfil
		}
		add_action( 'admin_menu', 'remove_default_menu' );
		
	}
	add_filter( 'woocommerce_admin_disabled', '__return_true' );
}
// Get the user object.
// $user = wp_get_userdata( $user_id );

// // Get all the user roles as an array.
// $user_roles = $user->roles;

// // Check if the role you're interested in, is present in the array.
// if ( in_array( 'show_manager', $user_roles, true ) ) {

	// function remove_default_menu(){
	// 	remove_submenu_page( 'edit.php', 'edit-tags.php?taxonomy=category' );
	// 	remove_menu_page('index.php'); // Dashboard
	// 	remove_menu_page('edit.php'); // Posts
	// 	remove_menu_page('upload.php'); // Media
	// 	remove_menu_page('link-manager.php'); // Links
	// 	remove_menu_page('edit.php?post_type=page'); // Pages
	// 	remove_menu_page('edit-comments.php'); // Comments
	// 	remove_menu_page('themes.php'); // Appearance
	// 	remove_menu_page('plugins.php'); // Plugins
	// 	remove_menu_page('users.php'); // Users
	// 	remove_menu_page('tools.php'); // Tools
	// 	remove_menu_page('options-general.php'); // Settings
	// 	remove_menu_page( 'edit.php?post_type=acf-field-group' ); // ACF
	// 	remove_menu_page( 'admin.php?page=wc-admin' ); // Woocommerce
	// 	remove_menu_page( 'edit.php?post_type=product' ); // Produtos
	// 	remove_menu_page( 'woocommerce' ); // WOOCOMMERCE
	// 	remove_menu_page( 'admin.php?page=wc-admin' ); // WOOCOMMERCE
	// }
	
	// add_filter( 'woocommerce_admin_disabled', '__return_true' );
	
	// add_action( 'admin_menu', 'remove_default_menu' );

// }

if (!function_exists('is_rest')) {
    /**
     * Checks if the current request is a WP REST API request.
     * 
     * Case #1: After WP_REST_Request initialisation
     * Case #2: Support "plain" permalink settings
     * Case #3: URL Path begins with wp-json/ (your REST prefix)
     *          Also supports WP installations in subfolders
     * 
     * @returns boolean
     * @author matzeeable
     */
    function is_rest() {
        $prefix = rest_get_url_prefix( );
        if (defined('REST_REQUEST') && REST_REQUEST // (#1)
            || isset($_GET['rest_route']) // (#2)
                && strpos( trim( $_GET['rest_route'], '\\/' ), $prefix , 0 ) === 0)
            return true;

        // (#3)
        $rest_url = wp_parse_url( site_url( $prefix ) );
        $current_url = wp_parse_url( add_query_arg( array( ) ) );
        return strpos( $current_url['path'], $rest_url['path'], 0 ) === 0;
    }
}

function is_wplogin(){
    $ABSPATH_MY = str_replace(array('\\','/'), DIRECTORY_SEPARATOR, ABSPATH);
    return ((in_array($ABSPATH_MY.'wp-login.php', get_included_files()) || in_array($ABSPATH_MY.'wp-register.php', get_included_files()) ) || (isset($_GLOBALS['pagenow']) && $GLOBALS['pagenow'] === 'wp-login.php') || $_SERVER['PHP_SELF']== '/wp-login.php');
}

remove_action( 'in_admin_header', 'wp_admin_bar_render', 0 );
//disables top margin
add_filter( 'admin_title', function(){ $GLOBALS['wp_query']->is_embed=true;  add_action('admin_xml_ns', function(){ $GLOBALS['wp_query']->is_embed=false; } ); } );

add_filter('contextual_help_list','contextual_help_list_remove');
function contextual_help_list_remove(){
    global $current_screen;
    $current_screen->remove_help_tabs();
}

add_filter('screen_options_show_screen','screen_options_show_screen_off');
function screen_options_show_screen_off(){
    global $current_screen;
    $current_screen->remove_options();
}

// End Formating

// Mount

// * Register Orders Post Type
add_action( 'init', 'wecart_orders' );
function wecart_orders() {
	$labels = array(
		'name'               => _x( 'Pedidos', 'post type general name' ),
		'singular_name'      => _x( 'Pedido', 'post type singular name' ),
		'menu_name'          => _x( 'Pedidos', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Novo Pedido', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Pedido' ),
		'new_item'           => __( 'Novo Pedido' ),
		'edit_item'          => __( 'Editar Pedido' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todos os Pedidos' ),
		'search_items'       => __( 'Buscar Pedido' ),
		'parent_item_colon'  => __( 'Sub-Pedidos' ),
		'not_found'          => __( 'Pedido não encontrado.' ),
		'not_found_in_trash' => __( 'Pedido não encontrado na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-calendar',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'wecart-orders', $args );
}

// * Register assessments Post Type
add_action( 'init', 'wecart_assessments' );
function wecart_assessments() {
	$labels = array(
		'name'               => _x( 'Avaliações', 'post type general name' ),
		'singular_name'      => _x( 'Avaliação', 'post type singular name' ),
		'menu_name'          => _x( 'Avaliações', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Nova avaliação', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Avaliação' ),
		'new_item'           => __( 'Nova Avaliação' ),
		'edit_item'          => __( 'Editar Avaliação' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todas as Avaliações' ),
		'search_items'       => __( 'Buscar Avaliação' ),
		'parent_item_colon'  => __( 'Comentários' ),
		'not_found'          => __( 'Avaliação não encontrado.' ),
		'not_found_in_trash' => __( 'Avaliação não encontrado na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-testimonial',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'wecart-assessments', $args );
}

//* Register Estoque Post Type
add_action( 'init', 'wecart_stock' );
function wecart_stock() {
	$labels = array(
		'name'               => _x( 'Controle de Estoque', 'post type general name' ),
		'singular_name'      => _x( 'Produto', 'post type singular name' ),
		'menu_name'          => _x( 'Estoque', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Novo Produto', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Produto ao Estoque' ),
		'new_item'           => __( 'Novo Produto' ),
		'edit_item'          => __( 'Editar Produto' ),
		'view_item'          => __( 'Mais informações' ),
		'all_items'          => __( 'Todos os Produtos' ),
		'search_items'       => __( 'Buscar no Estoque' ),
		// 'parent_item_colon'  => __( 'Parent Estoque:' ),
		'not_found'          => __( 'Produto não encontrado' ),
		'not_found_in_trash' => __( 'Produto não encontrado na lixeira' )
	);

	$args = array(
		'labels'             => $labels,
		// 'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'wecart-stock' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-archive',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'wecart-stock', $args );
}

// * Register Payments Post Type
add_action( 'init', 'wecart_payment_methods' );
function wecart_payment_methods() {
	$labels = array(
		'name'               => _x( 'Formas de Pagamento', 'post type general name' ),
		'singular_name'      => _x( 'Pagamento', 'post type singular name' ),
		'menu_name'          => _x( 'Formas de Pagamento', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Adicionar Novo', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Produto ao Estoque' ),
		'new_item'           => __( 'New Project' ),
		'edit_item'          => __( 'Edit Project' ),
		'view_item'          => __( 'View Project' ),
		'all_items'          => __( 'Todos os Produtos' ),
		'search_items'       => __( 'Search Estoque' ),
		'parent_item_colon'  => __( 'Parent Estoque:' ),
		'not_found'          => __( 'No Estoque found.' ),
		'not_found_in_trash' => __( 'No Estoque found in Trash.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-tickets-alt',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'payment-methods', $args );
}

// * Register Delivery Area Post Type
add_action( 'init', 'wecart_delivery_area' );
function wecart_delivery_area() {
	$labels = array(
		'name'               => _x( 'Áreas de Entrega', 'post type general name' ),
		'singular_name'      => _x( 'Área', 'post type singular name' ),
		'menu_name'          => _x( 'Áreas de Entrega', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Nova Área', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar região' ),
		'new_item'           => __( 'Nova Região' ),
		'edit_item'          => __( 'Editar Região' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todas as Regiões' ),
		'search_items'       => __( 'Buscar Região' ),
		'parent_item_colon'  => __( 'Sub-Região' ),
		'not_found'          => __( 'Região não encontrada.' ),
		'not_found_in_trash' => __( 'Região não encontrada na lixeira' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-location-alt',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'delivery_area', $args );
}

// * Register financial Post Type
add_action( 'init', 'wecart_financial' );
function wecart_financial() {
	$labels = array(
		'name'               => _x( 'Financeiro', 'post type general name' ),
		'singular_name'      => _x( 'Financeiro', 'post type singular name' ),
		'menu_name'          => _x( 'Financeiro', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Solicitar Repasse', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Repasse' ),
		'new_item'           => __( 'Novo Repasse' ),
		'edit_item'          => __( 'Editar Repasse' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todos os Repasses' ),
		'search_items'       => __( 'Buscar Repasse' ),
		'parent_item_colon'  => __( 'Sub-Repasses' ),
		'not_found'          => __( 'Repasse não encontrado.' ),
		'not_found_in_trash' => __( 'Repasse não encontrado na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-money-alt',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'financial', $args );
}

// * Register promotional Post Type
add_action( 'init', 'wecart_promo' );
function wecart_promo() {
	$labels = array(
		'name'               => _x( 'Promoções', 'post type general name' ),
		'singular_name'      => _x( 'Promoção', 'post type singular name' ),
		'menu_name'          => _x( 'Promoções', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Adicionar', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Promoção' ),
		'new_item'           => __( 'Nova Promoção' ),
		'edit_item'          => __( 'Editar Promoção' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todas as promoções' ),
		'search_items'       => __( 'Buscar Promoção' ),
		'parent_item_colon'  => __( 'Derivada' ),
		'not_found'          => __( 'Promoção não encontrada.' ),
		'not_found_in_trash' => __( 'Promoção não encontrada na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-bell',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'wecart-promo', $args );
}

// * Register Opening Hours Post Type
add_action( 'init', 'wecart_opening_hours' );
function wecart_opening_hours() {
	$labels = array(
		'name'               => _x( 'Horário de Funcionamento', 'post type general name' ),
		'singular_name'      => _x( 'Funcionamento', 'post type singular name' ),
		'menu_name'          => _x( 'Funcionamento', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Adicionar', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Horário' ),
		'new_item'           => __( 'Novo Horário' ),
		'edit_item'          => __( 'Editar horário' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todos os Horários' ),
		'search_items'       => __( 'Buscar Horário' ),
		'parent_item_colon'  => __( 'Derivada' ),
		'not_found'          => __( 'Hora não encontrada.' ),
		'not_found_in_trash' => __( 'Hora não encontrada na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-clock',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'opening_hours', $args );
}

// * Register Profile Post Type
add_action( 'init', 'wecart_profile' );
function wecart_profile() {
	$labels = array(
		'name'               => _x( 'Perfil', 'post type general name' ),
		'singular_name'      => _x( 'Perfil', 'post type singular name' ),
		'menu_name'          => _x( 'Perfil', 'admin menu' ),
		// 'name_admin_bar'     => _x( 'Project', 'add new on admin bar' ),
		'add_new'            => _x( 'Adicionar', 'Estoque' ),
		'add_new_item'       => __( 'Adicionar Horário' ),
		'new_item'           => __( 'Novo Horário' ),
		'edit_item'          => __( 'Editar horário' ),
		'view_item'          => __( 'Mais Informações' ),
		'all_items'          => __( 'Todos os Horários' ),
		'search_items'       => __( 'Buscar Horário' ),
		'parent_item_colon'  => __( 'Derivada' ),
		'not_found'          => __( 'Hora não encontrada.' ),
		'not_found_in_trash' => __( 'Hora não encontrada na lixeira.' )
	);

	$args = array(
		'labels'             => $labels,
		'description'        => __( 'Whiteley Designs Project Showcase.' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'project' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 11,
		'menu_icon'          => 'dashicons-store',
        // 'supports'           => array( 'title', 'editor', 'author', 'thumbnail' )
        'supports'           => array( '' )
	);

	register_post_type( 'wecart-profile', $args );
}

// End Mount

// Refine
function disable_new_orders() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=wecart-orders'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'wecart-orders') {
		echo '<style type="text/css">
		.page-title-action, .subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_orders');

function disable_profile() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=wecart-profile'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'wecart-profile') {
		echo '<style type="text/css">
		.page-title-action, .subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_profile');

function disable_new_time() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=opening_hours'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'opening_hours') {
		echo '<style type="text/css">
		.subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_time');

function disable_new_stock() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=wecart-stock'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'wecart-stock') {
		echo '<style type="text/css">
		.subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_stock');

function disable_new_payments() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=payment-methods'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'payment-methods') {
		echo '<style type="text/css">
		.page-title-action, .subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_payments');

function disable_new_assessments() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=wecart-assessments'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'wecart-assessments') {
		echo '<style type="text/css">
		.page-title-action, .subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_assessments');

function disable_new_delivery() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=delivery_area'][10]);
	
	// Hide link on listing page
	if (isset($_GET['post_type']) && $_GET['post_type'] == 'delivery_area') {
		echo '<style type="text/css">
		.page-title-action, .subsubsub { display:none; }
		</style>';
	}
}
add_action('admin_menu', 'disable_new_delivery');

function disable_promotional_menu() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=wecart-promo'][10]);

	if (isset($_GET['post_type']) && $_GET['post_type'] == 'wecart-promo') {
		echo '<style type="text/css">
		.subsubsub { display:none; }
		</style>';
	}	
}
add_action('admin_menu', 'disable_promotional_menu');

function disable_financial_menu() {
	// Hide sidebar link
	global $submenu;
	unset($submenu['edit.php?post_type=financial'][10]);

	if (isset($_GET['post_type']) && $_GET['post_type'] == 'financial') {
		echo '<style type="text/css">
		.subsubsub { display:none; }
		</style>';
	}	
}
add_action('admin_menu', 'disable_financial_menu');

function admin_menu_css() {
	echo '<style type="text/css">
	#collapse-menu { 
		display:none; 
	}
	#adminmenu, #adminmenu .wp-submenu, #adminmenuback, #adminmenuwrap {
		width: 250px!important
	}
	#wpcontent, #wpfooter {
		margin-left: 255px!important;
	}
	.logo-box img {
		width: 115px;
	}
	.logo-box {
		text-align: center;
		padding: 30px;
		padding-bottom: 10px;
	}
	#adminmenuwrap h3 {
		text-align: center;
		color: #fff;
		margin: 0;
		font-size: 13px;
		transform: translateY(-5px);
	}
	ul#adminmenu>li.current>a.current:after {
		display: none;
	}
	</style>';
}
add_action('admin_menu', 'admin_menu_css');

function admin_head_css() {
	echo '
		<style>
		.wrap h1{
			display: none;
		}
		</style>
	';
}

add_action('admin_head', 'admin_head_css');

function login_css() { ?>
    <style type="text/css">
        #login h1 a, .login h1 a {
            background-image: url(<?php echo get_theme_root_uri().'/wecart/assets/img/logo.png'?>);
			background-repeat: no-repeat;
			background-size: contain;
			background-position: center;
			width: 280px;
        }
		#loginform .submit #wp-submit {
			width: 100%;
			padding: 4px;
			margin-top: 14px;
			background: #0d6d8f;
			color: #ffffff;
			font-size: 15px;
			font-weight: 800;
			border-color: #0d6d8f;
		}		
		body.login {
    		background: #fff;
			background-image: url(<?php echo get_theme_root_uri().'/wecart/assets/img/mercado-bg.jpg'?>);
			background-repeat: no-repeat;
			background-position: -25% 100%;
    		background-size: 65% 100%;
			overflow: hidden;		
		}
		#login {
			display: table;
			width: 43.9%!important;
			height: 100%;
			float: right;
			padding: 4% 0 0!important;
			background: #fff;
			background: #34c0f3;
		}
		#login_error {
			color: #fff;
			position: absolute;
			bottom: -20px;
			background: #dc3232!important;
			width: 100%;
		}		
		#loginform {
			width: 60%;
			margin-left: auto;
			margin-right: auto;
			background: #25a0cc;
			color: #fff;
			font-weight: 600;
		}		
		.login form {
			border: none!important;
			box-shadow: none!important;
			margin-top: 45px!important;
		}		
    </style>
<?php }
add_action( 'login_enqueue_scripts', 'login_css' );

// End Refine

// Custom Home Url
add_action( 'admin_menu', 'linked_url' );
function linked_url() {
	add_menu_page( 'home_url', 'Sair', 'read', wp_logout_url( 'http://localhost/wecart' ), '', 'dashicons-share-alt2', 99 );
}
// Exit Url

// Dashboard notices

// System messages for Shop Manager
function author_admin_notice(){
    global $pagenow;
    if ( $pagenow == 'index.php' ) {
    	$user = wp_get_current_user();
    	if ( in_array( 'shop_manager', (array) $user->roles ) ) {
			echo '<div class="notice notice-info is-dismissible">
			<p>Todos contra o Covid: Conheça nossas politicas de proteção e combate ao corona vírus. <a>Saiba Mais</a></p>
			</div>';
			echo '<div class="notice notice-info is-dismissible">
			<p>Primeiros passos: Acesse nosso <a>Guia prático</a> e prepare-se para vender.</p>
			</div>';		 
		}
	}
}
add_action('admin_notices', 'author_admin_notice');

// system messages for all users
function general_admin_notice(){
    global $pagenow;
    if ( $pagenow == 'index.php' ) {
         echo '<div class="notice notice-warning is-dismissible">
             <p>Faremos manutenção em nossos servidores.</p>
         </div>';
    }
}
add_action('admin_notices', 'general_admin_notice');

// End Dashboard notices

add_action('wp_dashboard_setup', 'my_custom_dashboard_widgets');
  
function my_custom_dashboard_widgets() {
	global $wp_meta_boxes;
	wp_add_dashboard_widget('dashboard_widget', 'Total de Pedidos', 'custom_dashboard_help');
}
 
function custom_dashboard_help() {
	echo '<p>Welcome to Custom Blog Theme! Need help? Contact the developer <a href="mailto:yourusername@gmail.com">here</a>. For WordPress Tutorials visit: <a href="https://www.wpbeginner.com" target="_blank">WPBeginner</a></p>';
}